public enum EstadoAnimal {
    DISPONIBLE,
    ADOPTADO,
    ENTRATAMIENTO
}

